#usr/bin/bash
color="blu green red"
for color in $colors
do
	echo "color:$color"
done
