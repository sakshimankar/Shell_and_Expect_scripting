read -p "enter a: " a
read -p "enter b: " b
if [ $a -gt $b ];
then echo "a greater to b"
elif [ $a -eq $b ];
then echo "a equal to b"
else
	echo "b greater then a"
fi
