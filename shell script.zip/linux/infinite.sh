#/usr/bin/bash
while true
do echo "hi"
	sleep 1
done
