#!/bin/bash
time=$(date +%H)
echo $time
if [ $time -lt 12 ];then
    message="Good Morning User"
elif [ $time -lt 18 ];then
       message="Good Afternoon user"
else
 message="Good Evening User"
fi
echo "$message" 
