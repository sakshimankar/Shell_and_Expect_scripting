#/usr/bin/bash
correct=n
while [ "$correct" == "n" ]
do
	read -p "enter your name" name
	read -p "is your name ${name} correct?" correct
done
