#usr/bin/bash
n=5
for (( i=1 ; i<=n ; i++ ));
do
	if [ $i -eq 3 ]; then
		continue
	fi
	echo $i
done
