#!/bin/bash

# Function to check if directory exists
dir_exists() {
    [ -d "$1" ]
}

# Function to check if file exists
file_exists() {
    [ -f "$1" ]
}

# Function to get content of all files with a given name in a directory
get_file_contents() {
    local dir="$1"
    local file_name="$2"
    local files
    files=$(find "$dir" -type f -name "$file_name")
    if [ -z "$files" ]; then
        echo "No files with name $file_name found in directory."
    else 
        while IFS= read -r file; do
            if [ -f "$file" ]; then
                echo "Content of $file: "
                cat "$file"
                echo ""
            else
                echo "File $file does not exist."
            fi
        done <<< "$files"
    fi
}

# Function to list all files in a directory and list its content
list_files_and_contents() {
    local dir="$1"
    if ! [ -d "$dir" ]; then
        echo "Directory $dir does not exist."
        return
    fi

    local files
    files=$(ls "$dir" 2>/dev/null)
    if [ -z "$files" ]; then
        echo "No files found in directory $dir."
    else
        echo "Files in directory $dir are:"
        for file in $files; do
            local file_path="$dir/$file"
            if [ -f "$file_path" ]; then
                echo "Contents of $file_path: "
                cat "$file_path"
                echo ""
            else
                echo "File $file_path does not exist."
            fi
        done
    fi
}

# Main function script
main() {
    # Prompt for directory name
    read -p "Enter directory name: " dir_name

    # Check if directory exists
    if dir_exists "$dir_name"; then
        echo "Directory $dir_name already exists."
        list_files_and_contents "$dir_name"
        exit 0
    else
        # Create directory
        mkdir "$dir_name" 2>/dev/null
        if [ $? -eq 0 ]; then
            echo "Directory with name $dir_name created."
        else
            echo "Failed to create directory $dir_name. Check permissions."
            exit 1
        fi
    fi
    
    # Prompt for file name
    read -p "Enter file name: " file_name

    # Define file path with the correct directory name
    file_path="$dir_name/$file_name"

    # Check if file exists in the directory
    if file_exists "$file_path"; then
        echo "File $file_path already exists in directory $dir_name."
        get_file_contents "$dir_name" "$file_name"
        exit 0
    else
        # Create file and write data into it
        read -p "Enter the data to be inserted into the file: " file_data
        echo "$file_data" > "$file_path"
        if [ $? -eq 0 ]; then
            echo "File $file_name created with the provided data into the directory $dir_name."
        else
            echo "Failed to create file $file_name. Check permissions."
            exit 1
        fi
    fi 
}

# Run the main function
main

