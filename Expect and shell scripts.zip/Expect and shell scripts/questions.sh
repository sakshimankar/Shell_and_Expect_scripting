#/usr/bin/bash
#Questions

echo -e "Hi\n"
read $REPLY

echo -e "How are you?\n"
read $REPLY

echo -e "What's your name?\n"
read $REPLY
