#!/bin/bash

echo "Password required:"
read -s password
if [ "$password" == "sakshi@1" ]; then
    echo "Password accepted."
else
    echo "Incorrect password."
fi