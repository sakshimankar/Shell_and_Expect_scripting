#!/bin/bash

# Function to check if a directory exists
dir_exists() {
    [ -d "$1" ]
}
 
# Function to check if a file exists
file_exists() {
    [ -f "$1" ]
}

# Function to get the contents of all files with a given name in a directory
get_file_contents() {
    local dir="$1"
    local file_name="$2"
    local files
    files=$(find "$dir" -type f -name "$file_name")
    if [ -z "$files" ]; then
        echo "No files with name $file_name found."
    else
        while IFS= read -r file; do
            echo "Contents of $file:"
            cat "$file"
            echo ""
        done <<< "$files"
    fi
}

# Function to list all files in a directory and print their contents
list_files_and_contents() {
    local dir="$1"
    local files
    files=$(ls "$dir")
    if [ -z "$files" ]; then
        echo "No files found in directory $dir."
    else
        echo "Files in directory $dir:"
        echo "$files"
        echo ""
        for file in $files; do
            local file_path="$dir/$file"
            if [ -f "$file_path" ]; then
                echo "Contents of $file_path:"
                cat "$file_path"
                echo ""
            fi
        done
    fi
}

# Main script
main() {
    # Prompt for directory name
    read -p "Enter directory name: " dir_name

    # Check if directory exists
    if dir_exists "$dir_name"; then
        echo "Directory $dir_name already exists."
        list_files_and_contents "$dir_name"
        exit 0
    else
        # Create directory
        mkdir "$dir_name"
        echo "Directory $dir_name created."
    fi

    # Prompt for file name
    read -p "Enter file name: " file_name

    # Check if file exists in the directory
    file_path="$dir_name/$file_name"
    if file_exists "$file_path"; then
        echo "File $file_name already exists in $dir_name."
        get_file_contents "$dir_name" "$file_name"
        exit 0
    else
        # Create file and write data to it
        read -p "Enter data to be inserted in the file: " file_data

        echo "$file_data" > "$file_path"
        echo "File $file_name created in $dir_name with the provided data."
    fi
}

# Run the main function
main