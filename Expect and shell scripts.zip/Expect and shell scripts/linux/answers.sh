#usr/bin/expect -f

set timeout -1

spawn ./questions.sh

expect "Hi"
send "Hi\r"

expect eof


