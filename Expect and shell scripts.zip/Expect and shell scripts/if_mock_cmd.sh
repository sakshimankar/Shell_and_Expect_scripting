#!/bin/bash

echo "Enter command:"
read command
if [ "$command" == "show" ]; then
    echo "Show command executed."
elif [ "$command" == "hide" ]; then
    echo "Hide command executed."
else
    echo "Unknown command."
fi
